package edu.ncsu.csc520.hw01.searching_robot;

public class Node {
	private int xCoord;
	private int yCoord;
	private Node par;
	private int steps;
	private int fCost;
	public Node(int x, int y, Node Parent, int hCost) {
		setxCoord(x);
		setyCoord(y);
		setPar(Parent);
		
		
		if(Parent != null) {
			setfCost(steps + hCost);
			setSteps(Parent.getSteps() + 1);
		} else {
			setfCost(hCost);
			setSteps(0);
		}
	}
	/**
	 * @return the steps
	 */
	public int getSteps() {
		return steps;
	}
	/**
	 * @param steps the steps to set
	 */
	public void setSteps(int steps) {
		this.steps = steps;
	}
	/**
	 * @return the xCoord
	 */
	public int getxCoord() {
		return xCoord;
	}
	/**
	 * @param xCoord the xCoord to set
	 */
	public void setxCoord(int xCoord) {
		this.xCoord = xCoord;
	}
	/**
	 * @return the yCoord
	 */
	public int getyCoord() {
		return yCoord;
	}
	/**
	 * @param yCoord the yCoord to set
	 */
	public void setyCoord(int yCoord) {
		this.yCoord = yCoord;
	}
	/**
	 * @return the par
	 */
	public Node getPar() {
		return par;
	}
	/**
	 * @param par the par to set
	 */
	public void setPar(Node par) {
		this.par = par;
	}
	/**
	 * @return the fCost
	 */
	public int getfCost() {
		return fCost;
	}
	/**
	 * @param fCost the fCost to set
	 */
	public void setfCost(int fCost) {
		this.fCost = fCost;
	}
	
	@Override
	public boolean equals(Object o) {
		Node n = (Node) o;
		return this.getxCoord() == n.getxCoord() && this.getyCoord() == n.getyCoord();
	}
	@Override
	public String toString() {
		return "Node [xCoord=" + xCoord + ", yCoord=" + yCoord + "]";
	}
	
	
	
}
