package edu.ncsu.csc520.hw01.searching_robot;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;

/**
	Represents an intelligent agent moving through a particular room.	
	The robot only has one sensor - the ability to get the status of any  
	tile in the environment through the command env.getTileStatus(row, col).
	
	Your task is to modify the getAction method below so that is reached the
	TARGET POSITION with a minimal number of steps. There is only one (1)
	target position, which you can locate using env.getTargetRow() and env.getTargetCol()
*/

public class Robot {
	private Environment env;
	private int posRow;
	private int posCol;
	private String searchAlgorithm;
	//This is used to hold the path followed in A-Star
	private List<Node> actionPlan;
	
	//The following are used for OnlineDFS
	//Table that keeps track of the locations and actions tried at the locations
	Hashtable<String, Action> result = new Hashtable<String, Action>();
	//Table that lists for each node the actions that have not been tried
	Hashtable<String, List<Action>> untried = new Hashtable<String, List<Action>>();
	//Table that lists the backtracks not tried
	Hashtable<String, List<String>> unbacktracked = new Hashtable<String, List<String>>();
	//Previous node and action
	Node parent = null;
	Action previous = null;
	
	//The following are used for improvedHillclimbing
	List<String> tabuList = new LinkedList<String>();
	
	/**
	    Initializes a Robot on a specific tile in the environment. 
	*/
	public Robot (Environment env) { this(env, 0, 0, ""); }
	public Robot (Environment env, int posRow, int posCol, String searchAlgorithm) {
		this.env = env;
		this.posRow = posRow;
		this.posCol = posCol;
		this.searchAlgorithm = searchAlgorithm;
	}
	public int getPosRow() { return posRow; }
	public int getPosCol() { return posCol; }
	public void incPosRow() { posRow++; }
	public void decPosRow() { posRow--; }
	public void incPosCol() { posCol++; }
    public void decPosCol() { posCol--; }
	
    /**
     * Construct search tree before Robot start moving.
     */
    public void plan(){
    	switch(searchAlgorithm){
		case "AStar":
			actionPlan =  aStarPlan();
		case "OLDFS":
		case "OLHillClimbing":
		case "OLImprovedHillClimbing":
		default:
			break;
    	}
    }
    
    public List<Node> aStarPlan() {
    	//List that represents the locations that need to have their neighbors expanded
    	List<Node> open = new LinkedList<Node>();
    	//List of the locations that have had their neighbors expanded
    	List<Node> closed = new LinkedList<Node>();
    	//The path to take
    	List<Node> path = new LinkedList<Node>();
    	
    	//Each array will keep track of the row position, column position, estimated distance, and number of steps taken
    	Node start = new Node(getPosCol(), getPosRow(), null, manhattanDistance(getPosCol(), getPosRow()));
    	
    	//add the robot starting point to 
    	open.add(start);
    	
    	boolean goalFound = false;
    	//While there are still nodes to expand
    	while(!open.isEmpty() && !goalFound) {
    		Node expand = new Node(0,0,null,Integer.MAX_VALUE);
    		
    		//Find the node that has the lowest f cost and explore that one first
    		for(Node possible: open) {
    			if(possible.getfCost() < expand.getfCost()) {
    				expand = possible;
    			}
    		}
    		
    		open.remove(expand);
    		
    		//Expand in the four possible directions the robot can move
    		Node successor;
    		for(int i = 0; i < 4; i++) {
    			if(i == 0) {
    				successor = new Node(expand.getxCoord(), expand.getyCoord() + 1, expand, manhattanDistance(expand.getxCoord(), expand.getyCoord() + 1));
    				if(env.getTileStatus(successor.getyCoord(), successor.getxCoord()) == TileStatus.IMPASSABLE) {
    					//Do nothing
    				} else if(manhattanDistance(successor.getxCoord(), successor.getyCoord()) == 0 ) {
    					goalFound = true;
    					path.add(successor);
    					break;
    				}  else {
    					boolean add = true;
    					//If the location already exists with a lower cost do not add this one
    					for(Node nodesToExplore: open) {
    		    			if(nodesToExplore.getxCoord() == successor.getxCoord() && nodesToExplore.getyCoord() == successor.getyCoord() && (nodesToExplore.getfCost() <= successor.getfCost())) {
    		    				add = false;
    		    				break;
    		    			}
    		    		}
    					//If the node has already been expanded do not add it again
    					for(Node nodesExplored: closed) {
    						if(nodesExplored.getxCoord() == successor.getxCoord() && nodesExplored.getyCoord() == successor.getyCoord() && (nodesExplored.getfCost() <= successor.getfCost())) {
    		    				add = false;
    		    				break;
    		    			}
    		    		}
    					
    					if(add) {
    						open.add(successor);
    					}
    				}
    			} else if(i == 1) {
    				successor = new Node(expand.getxCoord(), expand.getyCoord() - 1, expand, manhattanDistance(expand.getxCoord(), expand.getyCoord() - 1));
    				if(env.getTileStatus(successor.getyCoord(), successor.getxCoord()) == TileStatus.IMPASSABLE) {
    					//Do nothing
    				} else if(manhattanDistance(successor.getxCoord(), successor.getyCoord()) == 0 ) {
    					goalFound = true;
    					path.add(successor);
    					break;
    				}   else {
    					boolean add = true;
    					//If the location already exists with a lower cost do not add this one
    					for(Node nodesToExplore: open) {
    		    			if(nodesToExplore.getxCoord() == successor.getxCoord() && nodesToExplore.getyCoord() == successor.getyCoord() && (nodesToExplore.getfCost() <= successor.getfCost())) {
    		    				add = false;
    		    				break;
    		    			}
    		    		}
    					//If the node has already been expanded do not add it again
    					for(Node nodesExplored: closed) {
    						if(nodesExplored.getxCoord() == successor.getxCoord() && nodesExplored.getyCoord() == successor.getyCoord() && (nodesExplored.getfCost() <= successor.getfCost())) {
    		    				add = false;
    		    				break;
    		    			}
    		    		}
    					
    					if(add) {
    						open.add(successor);
    					}
    				}
    			}else if(i == 2) {
    				successor = new Node(expand.getxCoord() + 1, expand.getyCoord(), expand, manhattanDistance(expand.getxCoord() + 1, expand.getyCoord()));
    				 if(env.getTileStatus(successor.getyCoord(), successor.getxCoord()) == TileStatus.IMPASSABLE) {
    					//Do nothing
     				} else if(manhattanDistance(successor.getxCoord(), successor.getyCoord()) == 0 ) {
    					goalFound = true;
    					path.add(successor);
    					break;
    				} else {
    					boolean add = true;
    					//If the location already exists with a lower cost do not add this one
    					for(Node nodesToExplore: open) {
    		    			if(nodesToExplore.getxCoord() == successor.getxCoord() && nodesToExplore.getyCoord() == successor.getyCoord() && (nodesToExplore.getfCost() <= successor.getfCost())) {
    		    				add = false;
    		    				break;
    		    			}
    		    		}
    					//If the node has already been expanded do not add it again
    					for(Node nodesExplored: closed) {
    						if(nodesExplored.getxCoord() == successor.getxCoord() && nodesExplored.getyCoord() == successor.getyCoord() && (nodesExplored.getfCost() <= successor.getfCost())) {
    		    				add = false;
    		    				break;
    		    			}
    		    		}
    					
    					if(add) {
    						open.add(successor);
    					}
    				}
    			} else if(i == 3) {
    				successor = new Node(expand.getxCoord() - 1, expand.getyCoord(), expand, manhattanDistance(expand.getxCoord() - 1, expand.getyCoord()));
    				if(env.getTileStatus(successor.getyCoord(), successor.getxCoord()) == TileStatus.IMPASSABLE) {
    					//Do nothing
    				} else if(manhattanDistance(successor.getxCoord(), successor.getyCoord()) == 0 ) {
    					goalFound = true;
    					path.add(successor);
    					break;
    				} else {
    					boolean add = true;
    					//If the location already exists with a lower cost do not add this one
    					for(Node nodesToExplore: open) {
    		    			if(nodesToExplore.getxCoord() == successor.getxCoord() && nodesToExplore.getyCoord() == successor.getyCoord() && (nodesToExplore.getfCost() <= successor.getfCost())) {
    		    				add = false;
    		    				break;
    		    			}
    		    		}
    					//If the node has already been expanded do not add it again
    					for(Node nodesExplored: closed) {
    						if(nodesExplored.getxCoord() == successor.getxCoord() && nodesExplored.getyCoord() == successor.getyCoord() && (nodesExplored.getfCost() <= successor.getfCost())) {
    		    				add = false;
    		    				break;
    		    			}
    		    		}
    					
    					if(add) {
    						open.add(successor);
    					}
    				}
    			}
    			
    			
    		
    		}
    		closed.add(expand);
    	}
    	
    	for(int i = closed.size() - 1; i >= 0; i--) {
    		Node n = closed.get(i);
    		for(Node o: path) {
    			if(o.getPar().equals(n)) {
    				path.add(0,n);
    				break;
    			}
    		}
    	}
    	return path;
    }
    
    private int manhattanDistance(int x, int y) {
    	return Math.abs((env.getTargetCol() - x)) + Math.abs((env.getTargetRow() - y));
    }
    /**
     * Online dfs algorithm that returns an action. I used our textbook for an outline of the algorithm
     * @return An action
     */
    public Action OnlineDFS() {
    	Action a = Action.DO_NOTHING;
    	if(getPosRow() == env.getTargetRow() && getPosCol() == env.getTargetCol()) {
    		return Action.DO_NOTHING;
    	}
    	Node newState = new Node(getPosCol(), getPosRow(), null, 0);
    	
    	if(!untried.containsKey(newState.toString())) {
    		List<Action> newActions = new LinkedList<Action>();
    		
    		if(env.getTileStatus(this.posRow + 1, this.getPosCol()) != TileStatus.IMPASSABLE) {
    			if(previous == null || previous != Action.MOVE_UP) {
    				newActions.add(Action.MOVE_DOWN);
    			}
    		}
    		if(env.getTileStatus(this.posRow, this.getPosCol() - 1) != TileStatus.IMPASSABLE) {
    			if(previous == null || previous != Action.MOVE_RIGHT) {
    				newActions.add(Action.MOVE_LEFT);
    			}
    		}
    		
    		if(env.getTileStatus(this.posRow , this.getPosCol() + 1) != TileStatus.IMPASSABLE) {
    			if(previous == null || previous != Action.MOVE_LEFT) {
    				newActions.add(Action.MOVE_RIGHT);
    			}
    		}
    		
    		if(env.getTileStatus(this.posRow - 1, this.getPosCol()) != TileStatus.IMPASSABLE) {
    			if(previous == null || previous != Action.MOVE_DOWN) {
    				newActions.add(Action.MOVE_UP);
    			}
    		}
    		untried.put(newState.toString(), newActions);
    	}
    	
    	if(parent != null) {
    		result.put(parent.toString(), previous);
    		List<String> update = unbacktracked.get(newState.toString());
    		if(update == null) {
    			update = new LinkedList<String>();
    		}
    		update.add(0, parent.toString());
    		unbacktracked.replace(newState.toString(), update);
    	}
    	if(untried.get(newState.toString()).isEmpty()) {
    		if(unbacktracked.get(newState.toString()).isEmpty()) {
    			return Action.DO_NOTHING;
    		} else {
    			String pathBack = unbacktracked.get(newState.toString()).remove(0);
    			Action undo = result.get(pathBack);
    			if(undo == Action.MOVE_DOWN) {
    				a = Action.MOVE_UP;
    			} else if(undo == Action.MOVE_UP) {
    				a = Action.MOVE_DOWN;
    			} else if(undo == Action.MOVE_LEFT) {
    				a = Action.MOVE_RIGHT;
    			} else if(undo == Action.MOVE_RIGHT) {
    				a = Action.MOVE_LEFT;
    			}
    		}
    	} else {
    		a = untried.get(newState.toString()).remove(0);
    	}
    	parent = newState;
    	return a;
    }
	
    /**
     * The basic hill climbing algorithm
     * @return the action the robot should take
     */
    public Action OLHillClimbing() {
    	//Start out doing nothing and see if there is a better option
    	Action a = Action.DO_NOTHING;
    	int minFCost = manhattanDistance(this.posCol, this.posRow);
    	
    	if(manhattanDistance(this.posCol - 1, this.posRow) < minFCost && env.getTileStatus(this.posRow, this.posCol - 1) != TileStatus.IMPASSABLE) {
    		minFCost = manhattanDistance(this.posCol - 1, this.posRow);
    		a = Action.MOVE_LEFT;
    	}
    	if(manhattanDistance(this.posCol + 1, this.posRow) < minFCost && env.getTileStatus(this.posRow, this.posCol + 1) != TileStatus.IMPASSABLE) {
    		minFCost = manhattanDistance(this.posCol - 1, this.posRow);
    		a = Action.MOVE_RIGHT;
    	}
    	if(manhattanDistance(this.posCol, this.posRow - 1) < minFCost && env.getTileStatus(this.posRow - 1, this.posCol) != TileStatus.IMPASSABLE) {
    		minFCost = manhattanDistance(this.posCol - 1, this.posRow);
    		a = Action.MOVE_UP;
    	}
    	if(manhattanDistance(this.posCol, this.posRow + 1) < minFCost && env.getTileStatus(this.posRow + 1, this.posCol) != TileStatus.IMPASSABLE) {
    		minFCost = manhattanDistance(this.posCol - 1, this.posRow);
    		a = Action.MOVE_DOWN;
    	}
    	
    	return a;
    	
    }
    
    /**
     * Improved hill climbing with sideways movement and a tabu search
     * @return the action the robot should take
     */
    public Action improvedOLHillClimbing() {
    	//Start out doing nothing and see if there is a better option
    	Action a = Action.DO_NOTHING;
    	int minFCost = manhattanDistance(this.posCol, this.posRow);
    	
    	//This array is to check the tabuList
    	Node newPosition = new Node(this.posCol - 1, this.posRow, null, 0);
    	if(manhattanDistance(this.posCol - 1, this.posRow) <= minFCost && !tabuList.contains(newPosition.toString()) && env.getTileStatus(this.posRow, this.posCol - 1) != TileStatus.IMPASSABLE) {
    		minFCost = manhattanDistance(this.posCol - 1, this.posRow);
    		a = Action.MOVE_LEFT;
    	}
    	newPosition.setxCoord(this.posCol + 1);
    	newPosition.setyCoord(this.posRow);
    	if(manhattanDistance(this.posCol + 1, this.posRow) <= minFCost && !tabuList.contains(newPosition.toString()) && env.getTileStatus(this.posRow, this.posCol + 1) != TileStatus.IMPASSABLE) {
    		minFCost = manhattanDistance(this.posCol - 1, this.posRow);
    		a = Action.MOVE_RIGHT;
    	}
    	newPosition.setxCoord(this.posCol);
    	newPosition.setyCoord(this.posRow - 1);
    	if(manhattanDistance(this.posCol, this.posRow - 1) <= minFCost && !tabuList.contains(newPosition.toString()) && env.getTileStatus(this.posRow - 1, this.posCol) != TileStatus.IMPASSABLE) {
    		minFCost = manhattanDistance(this.posCol - 1, this.posRow);
    		a = Action.MOVE_UP;
    	}
    	newPosition.setxCoord(this.posCol);
    	newPosition.setyCoord(this.posRow + 1);
    	if(manhattanDistance(this.posCol, this.posRow + 1) <= minFCost && !tabuList.contains(newPosition.toString()) && env.getTileStatus(this.posRow + 1, this.posCol) != TileStatus.IMPASSABLE) {
    		minFCost = manhattanDistance(this.posCol - 1, this.posRow);
    		a = Action.MOVE_DOWN;
    	}
    	
    	//Add the selected new position to the tabu list
    	if(a == Action.MOVE_LEFT) {
    		newPosition.setxCoord(this.posCol - 1);
        	newPosition.setyCoord(this.posRow);
    		tabuList.add(newPosition.toString());
    	} else if(a == Action.MOVE_RIGHT) {
    		newPosition.setxCoord(this.posCol + 1);
        	newPosition.setyCoord(this.posRow);
    		tabuList.add(newPosition.toString());
    	}  else if(a == Action.MOVE_UP) {
    		newPosition.setxCoord(this.posCol);
        	newPosition.setyCoord(this.posRow - 1);
    		tabuList.add(newPosition.toString());
    	}  else if(a == Action.MOVE_DOWN) {
    		newPosition.setxCoord(this.posCol);
        	newPosition.setyCoord(this.posRow + 1);
    		tabuList.add(newPosition.toString());
    	}
    	
    	//If there is no way to go downhill find the best uphill route
    	if(a == Action.DO_NOTHING && !env.goalConditionMet(this)) {
    		//Ensure all moves will have a lower f cost
    		minFCost = Integer.MAX_VALUE;
        	
        	//This array is to check the tabuList
    		Node newPosition2 = new Node(this.posCol - 1, this.posRow, null, 0);
        	if(manhattanDistance(this.posCol - 1, this.posRow) <= minFCost && !tabuList.contains(newPosition2.toString()) && env.getTileStatus(this.posRow, this.posCol - 1) != TileStatus.IMPASSABLE) {
        		minFCost = manhattanDistance(this.posCol - 1, this.posRow);
        		a = Action.MOVE_LEFT;
        	}
        	newPosition2.setxCoord(this.posCol + 1);
        	newPosition2.setyCoord(this.posRow);
        	if(manhattanDistance(this.posCol + 1, this.posRow) <= minFCost && !tabuList.contains(newPosition2.toString()) && env.getTileStatus(this.posRow, this.posCol + 1) != TileStatus.IMPASSABLE) {
        		minFCost = manhattanDistance(this.posCol - 1, this.posRow);
        		a = Action.MOVE_RIGHT;
        	}
        	newPosition2.setxCoord(this.posCol);
        	newPosition2.setyCoord(this.posRow - 1);
        	if(manhattanDistance(this.posCol, this.posRow - 1) <= minFCost && !tabuList.contains(newPosition2.toString()) && env.getTileStatus(this.posRow - 1, this.posCol) != TileStatus.IMPASSABLE) {
        		minFCost = manhattanDistance(this.posCol - 1, this.posRow);
        		a = Action.MOVE_UP;
        	}
        	newPosition2.setxCoord(this.posCol);
        	newPosition2.setyCoord(this.posRow + 1);
        	if(manhattanDistance(this.posCol, this.posRow + 1) <= minFCost && !tabuList.contains(newPosition2.toString()) && env.getTileStatus(this.posRow + 1, this.posCol) != TileStatus.IMPASSABLE) {
        		minFCost = manhattanDistance(this.posCol - 1, this.posRow);
        		a = Action.MOVE_DOWN;
        	}
        	
        	//Add the selected new position to the tabu list
        	if(a == Action.MOVE_LEFT) {
        		newPosition2.setxCoord(this.posCol - 1);
            	newPosition2.setyCoord(this.posRow);
        		tabuList.add(newPosition2.toString());
        	} else if(a == Action.MOVE_RIGHT) {
        		newPosition2.setxCoord(this.posCol + 1);
            	newPosition2.setyCoord(this.posRow);
        		tabuList.add(newPosition2.toString());
        	}  else if(a == Action.MOVE_UP) {
        		newPosition2.setxCoord(this.posCol);
            	newPosition2.setyCoord(this.posRow - 1);
        		tabuList.add(newPosition2.toString());
        	}  else if(a == Action.MOVE_DOWN) {
        		newPosition2.setxCoord(this.posCol);
            	newPosition2.setyCoord(this.posRow + 1);
        		tabuList.add(newPosition2.toString());
        	}
    	}
    	return a;
    	
    }
    /**
	    Simulate the passage of a single time-step.
	    At each time-step, the Robot decides which direction
	    to move.
	*/
	public Action getAction () {
		// you can get a tile's status with
		TileStatus status = env.getTileStatus(posRow, posCol);
		
		if (status == TileStatus.TARGET){
			System.out.println("Goal Found");
			
		}
		
		Action action = Action.DO_NOTHING;
		
		switch(searchAlgorithm){
		case "OLDFS":
			action = OnlineDFS();
			previous = action;
			break;
		case "OLHillClimbing":
			action = OLHillClimbing();
			
			break;
		case "OLImprovedHillClimbing":
			action = improvedOLHillClimbing();
			
			break;
		case "AStar":
			
			while(true) {
				Node location = actionPlan.remove(0);
				if(location.getxCoord() < getPosCol() && location.getyCoord() == getPosRow()) {
					action = Action.MOVE_LEFT;
					break;
				} else if(location.getxCoord() > getPosCol() && location.getyCoord() == getPosRow()) {
					action = Action.MOVE_RIGHT;
					break;
				}  else if(location.getxCoord() == getPosCol() && location.getyCoord() < getPosRow()) {
					action = Action.MOVE_UP;
					break;
				}  else if(location.getxCoord() == getPosCol() && location.getyCoord() > getPosRow()) {
					action = Action.MOVE_DOWN;
					break;
				}
			}
		default:
			break;
    	}
		
	    return action;
	}
	
}